import requests
#color = ""
#while True:
for i in range(1,2):
	f3 = open("c" + str(i), 'r')
	x = f3.read()   # x defines color
	print "c"+str(i)+":"+x
	color = requests.get('http://192.168.1.30/rgb/' + x  + '/c')
	print color
	f3.close();
#	print color.text
#sys.stdout.flush()
