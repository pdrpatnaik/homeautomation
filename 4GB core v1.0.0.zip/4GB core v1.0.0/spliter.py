def map(x, in_min, in_max, out_min, out_max):
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
x=open('c1','r') 
f=x.read() 
r=int(f[0:2],16) 
g=int(f[2:4],16) 
b=int(f[4:6],16) 
print (map(r, 00, 255, 00, 99)) 
print (map(g, 00, 255, 00, 99)) 
print (map(b, 00, 255, 00, 99))
x.close()
