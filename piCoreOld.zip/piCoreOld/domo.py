import RPi.GPIO as GPIO
import time
switch = [0, 2, 3, 4, 17, 27 ,22 ,10, 9, 11] #9 switches ~ these are pin numbers as per BCM standard pinouts refer pinout.xyz
dim = [0, 5, 6, 26, 16] #4 dig pins of fan dimmer module D3-D2-D1-D0
color = [0, 18, 12, 13] #3 RGB pins for LED color strip
speed = [[-1,-1,-1,-1],[1, 1, 1, 1], [1, 0, 0, 1], [0, 1, 1, 1], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 0]] # [00%, 30%, 50%, 65%, 80%, 100%]
# Input for Dimmer module is of digital input of 4bit data.D0, D1, D2, D3 are the input pins of 
# dimmer which can be connected to I/O pins of microcontroller. 16 level of dimmer controlling input of 0 to 100% is shown below.
# I/p	D3	D2	D1	D0	Dim%
# 0	0	0	0	0	100
# 1	0	0	0	1	86
# 2	0	0	1	0	80
# 3	0	0	1	1	75
# 4	0	1	0	0	70
# 5	0	1	0	1	65
# 6	0	1	1	0	60
# 7	0	1	1	1	50
# 8	1	0	0	0	40
# 9	1	0	0	1	30
# 10	1	0	1	0	25
# 11	1	0	1	1	20
# 12	1	1	0	0	15
# 13	1	1	0	1	10
# 14	1	1	1	0	05
# 15	1	1	1	1	00

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

for i in range(1,10): # for relay board initial values is set high as it acts to be active low
	GPIO.setup(switch[i], GPIO.OUT)
	GPIO.output(switch[i], GPIO.LOW)
for i in range(1,5): # for fan
        GPIO.setup(dim[i], GPIO.OUT)
        GPIO.output(dim[i], GPIO.LOW)
for i in range(1,4): # for color
        GPIO.setup(color[i], GPIO.OUT)
        GPIO.output(color[i], GPIO.LOW)

while True:
	for i in range(1,10):
		f1 = open("s" + str(i), 'r')
		x = f1.read()
		if x != '':
#			print "s"+str(i)+":"+x
			GPIO.output(switch[i], int(x))
		f1.close();
	for i in range(1,4):
                f2 = open("d" + str(i), 'r')
                x = f2.read()	# x defines speed selection
#		print "d"+str(i)+":"+x
		if x !='':
			for j in speed[int(x)]:
				GPIO.output(dim[i],j);
		f2.close();
	for i in range(1,1):
                f3 = open("c" + str(i), 'r')
                x = f3.read()   # x defines speed selection
 #    	  	print "c"+str(i)+":"+x
                if x !='':
			temp = x[-4:]
	                r = x[:2]
        	        g = temp[:2]
                	b = temp[-2:]
			pwmR = GPIO.PWM(color[1] ,1000)
                	pwmG = GPIO.PWM(color[2] ,1000)
	                pwmB = GPIO.PWM(color[3] ,1000)
			pwmR.start(0)
			pwmG.start(0)
			pwmB.start(0)
                        pwmR.ChangeDutyCycle(int(r))
			pwmG.ChangeDutyCycle(int(g))
			pwmB.ChangeDutyCycle(int(b))
                f3.close();

