import falcon 

for i in range(1,10): 
	f1 = open("s" + str(i), 'w')
	f1.write('0')
	f1.close()
for i in range(1,4):
	f1 = open("d" + str(i), 'w')
	f1.write('0')
	f1.close()

f1 = open('c1','w')
f1.write('000000')
f1.close()

class ThingsResource(object):
	def on_get(self, req, resp, pin, val):
		resp.status = falcon.HTTP_200 # This is the default status
		if pin == "getstatus":
			x = '{"switch":["s1","s2","s3","s4","s5","s6","s7","s8","s9","d1","d2","d3","c1"],"status":["'
			for i in range(1,10):
				f1 = open("s" + str(i), 'r')
				x = x + f1.read() + '","'
				f1.close()

			for i in range(1,4):
				f1 = open("d" + str(i), 'r')
				x = x + f1.read() + '","'
				f1.close()

			f1 = open('c1','r')
			x = x + f1.read() + '"]}' 
			f1.close()

			print (x) 
			respo = x
		else:
			fObj = open(pin,'w')
			fObj.write(val)
			respo = '{"switch":"' + pin + '","status":"' + val + '"}'
			
		resp.body = respo
		
app = falcon.API() 
obj = ThingsResource() 
app.add_route('/status/{pin}/{val}', obj)

